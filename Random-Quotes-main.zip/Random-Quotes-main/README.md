#Quotes-Collection
Quotes Collection contributed by people around the world who uses github, can be an already existing one or can be your own imagination, until it goes south

```diff
+ Add in Your Quotes in the quotes.json file, if you wish to add more quotes add in another json object with the data
- Do not update, delete any other files
```
# How Your JSON file should look like 
```diff

    {
      "quotes":[
          {
            "name":"Muhammad Bilal Saleem",
            "userName":"Bilal-pk",
            "quotes":"You are either true or You are false, this is a Boolean world"
          }
+         ,
+         {
+           "name":"Your Full Name",
+           "userName":"Your Github Username",
+           "quotes":"Your Quote to others"
+         }
      ]
  }

```
